# 🤖 AYRA - Advanced Yielding Response Assistant
### Android Voice AI Assistant | Bengali & Multi-language | Root Support

---

## ✨ Features

| Feature | Status |
|--------|--------|
| 🎙 Voice Input (All Languages) | ✅ |
| 🔊 Natural Girl Voice (TTS) | ✅ |
| 🤖 Gemini AI Integration | ✅ |
| 💬 ChatGPT (OpenAI) Integration | ✅ |
| ⚡ Grok (xAI) Integration | ✅ |
| 📱 App Launch via Voice | ✅ |
| 📞 Call via Voice | ✅ |
| 📸 Screenshot Command | ✅ |
| 🔦 Flashlight Control | ✅ |
| 🔵 Floating Orb Overlay | ✅ |
| 🔐 Root (su) Commands | ✅ |
| 🌐 10+ Languages | ✅ |
| 🔄 Boot Auto-start | ✅ |

---

## 📁 Project Structure

```
AYRA_VoiceAssistant/
├── app/src/main/
│   ├── AndroidManifest.xml
│   ├── java/com/ayra/assistant/
│   │   ├── activities/
│   │   │   ├── SplashActivity.kt      ← Intro screen
│   │   │   ├── MainActivity.kt        ← Main chat + voice
│   │   │   └── SettingsActivity.kt    ← API keys input
│   │   ├── services/
│   │   │   ├── AIService.kt           ← Gemini/GPT/Grok API
│   │   │   ├── AppLaunchService.kt    ← Open apps, calls (root)
│   │   │   ├── FloatingOrbService.kt  ← Floating bubble
│   │   │   └── WakeWordService.kt     ← Background listener
│   │   ├── models/
│   │   │   └── ChatMessage.kt
│   │   └── utils/
│   │       ├── AyraAdapter.kt         ← Chat RecyclerView
│   │       ├── PrefsHelper.kt         ← API key storage
│   │       └── BootReceiver.kt        ← Auto-start on boot
│   └── res/
│       ├── layout/                    ← All XML layouts
│       ├── drawable/                  ← Icons & shapes
│       └── values/                    ← Colors, strings, themes
├── build.gradle
└── settings.gradle
```

---

## 🚀 GitHub থেকে Build করবেন কীভাবে

### Step 1: Prerequisites
```bash
# Install:
- Android Studio (Hedgehog or newer)
- JDK 17
- Android SDK 34
```

### Step 2: Clone & Open
```bash
git clone https://github.com/yourusername/AYRA.git
cd AYRA
# Open in Android Studio
```

### Step 3: Lottie Animations
`app/src/main/assets/` ফোল্ডারে এই দুটো JSON ফাইল রাখুন:
- `ayra_splash.json` - Splash screen animation
- `ayra_orb.json` - Speaking orb animation

> 🆓 Free animations: https://lottiefiles.com/search?q=ai+orb

### Step 4: Build
```
Build → Generate Signed Bundle/APK → APK → debug
```

---

## 🔑 API Keys কোথায় পাবেন

| AI | Key পাওয়ার লিঙ্ক | Free? |
|----|-----------------|-------|
| **Gemini** | https://aistudio.google.com/apikey | ✅ Free |
| **ChatGPT** | https://platform.openai.com/api-keys | 💰 Paid |
| **Grok** | https://console.x.ai | 💰 Paid |

---

## 📱 Voice Commands (বাংলা উদাহরণ)

```
"হোয়াটসঅ্যাপ খোলো"          → WhatsApp open হবে
"ইউটিউব খোলো"               → YouTube open হবে
"ক্যামেরা চালু করো"           → Camera open হবে
"টর্চ চালু"                  → Flashlight on
"টর্চ বন্ধ"                  → Flashlight off
"ভলিউম বাড়াও"               → Volume up
"স্ক্রিনশট নাও"              → Screenshot
"রহিম-কে কল করো"            → Call Rahim
```

---

## 📱 Root Phone Features

Root থাকলে AYRA আরো শক্তিশালী হবে:
- যেকোনো system app খুলতে পারবে
- Background থেকে app launch
- System-level volume/brightness control
- Shell commands execute করতে পারবে

Root ছাড়াও সব basic features কাজ করবে।

---

## 🌐 Supported Languages

বাংলা (BD/IN), English, Hindi, Arabic, Urdu, Spanish, French, Chinese + আরো

---

## 🎨 UI Screenshots

Dark purple theme, animated orb, chat bubbles, floating overlay

---

## 📄 License

MIT License - Free to use, modify, distribute

---

## 👨‍💻 Made with ❤️ for Bangladesh
**AYRA** - আপনার AI সহকারী
