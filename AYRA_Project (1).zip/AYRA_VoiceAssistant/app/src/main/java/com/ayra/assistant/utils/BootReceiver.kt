package com.ayra.assistant.utils

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.ayra.assistant.services.FloatingOrbService

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val prefs = PrefsHelper(context)
            if (prefs.isWakeWordEnabled()) {
                val serviceIntent = Intent(context, FloatingOrbService::class.java)
                context.startForegroundService(serviceIntent)
            }
        }
    }
}
