package com.ayra.assistant.activities

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.ayra.assistant.R
import com.ayra.assistant.utils.PrefsHelper

class SettingsActivity : AppCompatActivity() {

    private lateinit var prefs: PrefsHelper
    private lateinit var geminiKeyInput: EditText
    private lateinit var chatgptKeyInput: EditText
    private lateinit var grokKeyInput: EditText
    private lateinit var providerSpinner: Spinner
    private lateinit var languageSpinner: Spinner
    private lateinit var saveBtn: Button
    private lateinit var wakeWordSwitch: Switch
    private lateinit var autoStartSwitch: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        prefs = PrefsHelper(this)
        initViews()
        loadSavedValues()
        setupSaveButton()
    }

    private fun initViews() {
        geminiKeyInput = findViewById(R.id.input_gemini_key)
        chatgptKeyInput = findViewById(R.id.input_chatgpt_key)
        grokKeyInput = findViewById(R.id.input_grok_key)
        providerSpinner = findViewById(R.id.spinner_provider)
        languageSpinner = findViewById(R.id.spinner_language)
        saveBtn = findViewById(R.id.btn_save_settings)
        wakeWordSwitch = findViewById(R.id.switch_wake_word)
        autoStartSwitch = findViewById(R.id.switch_auto_start)

        // Provider options
        ArrayAdapter.createFromResource(
            this, R.array.ai_providers, android.R.layout.simple_spinner_item
        ).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            providerSpinner.adapter = adapter
        }

        // Language options
        ArrayAdapter.createFromResource(
            this, R.array.languages, android.R.layout.simple_spinner_item
        ).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            languageSpinner.adapter = adapter
        }
    }

    private fun loadSavedValues() {
        geminiKeyInput.setText(prefs.getGeminiKey())
        chatgptKeyInput.setText(prefs.getChatGPTKey())
        grokKeyInput.setText(prefs.getGrokKey())
        wakeWordSwitch.isChecked = prefs.isWakeWordEnabled()

        val providers = resources.getStringArray(R.array.ai_providers_values)
        val savedProvider = prefs.getAIProvider()
        providerSpinner.setSelection(providers.indexOf(savedProvider).coerceAtLeast(0))

        val languages = resources.getStringArray(R.array.language_values)
        val savedLang = prefs.getLanguage()
        languageSpinner.setSelection(languages.indexOf(savedLang).coerceAtLeast(0))
    }

    private fun setupSaveButton() {
        saveBtn.setOnClickListener {
            prefs.setGeminiKey(geminiKeyInput.text.toString().trim())
            prefs.setChatGPTKey(chatgptKeyInput.text.toString().trim())
            prefs.setGrokKey(grokKeyInput.text.toString().trim())
            prefs.setWakeWord(wakeWordSwitch.isChecked)

            val providers = resources.getStringArray(R.array.ai_providers_values)
            prefs.setAIProvider(providers[providerSpinner.selectedItemPosition])

            val languages = resources.getStringArray(R.array.language_values)
            prefs.setLanguage(languages[languageSpinner.selectedItemPosition])

            Toast.makeText(this, "সেটিংস সেভ হয়েছে!", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
