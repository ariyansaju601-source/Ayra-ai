package com.ayra.assistant.utils

import android.content.Context
import androidx.preference.PreferenceManager

class PrefsHelper(context: Context) {
    private val prefs = PreferenceManager.getDefaultSharedPreferences(context)

    // API Keys
    fun getGeminiKey(): String = prefs.getString("gemini_key", "") ?: ""
    fun setGeminiKey(key: String) = prefs.edit().putString("gemini_key", key).apply()

    fun getChatGPTKey(): String = prefs.getString("chatgpt_key", "") ?: ""
    fun setChatGPTKey(key: String) = prefs.edit().putString("chatgpt_key", key).apply()

    fun getGrokKey(): String = prefs.getString("grok_key", "") ?: ""
    fun setGrokKey(key: String) = prefs.edit().putString("grok_key", key).apply()

    // Active AI Provider: "gemini" | "chatgpt" | "grok"
    fun getAIProvider(): String = prefs.getString("ai_provider", "gemini") ?: "gemini"
    fun setAIProvider(provider: String) = prefs.edit().putString("ai_provider", provider).apply()

    // Language for STT
    fun getLanguage(): String = prefs.getString("language", "bn-BD") ?: "bn-BD"
    fun setLanguage(lang: String) = prefs.edit().putString("language", lang).apply()

    // Voice speed
    fun getSpeechRate(): Float = prefs.getFloat("speech_rate", 0.88f)
    fun setSpeechRate(rate: Float) = prefs.edit().putFloat("speech_rate", rate).apply()

    // Wake word enabled
    fun isWakeWordEnabled(): Boolean = prefs.getBoolean("wake_word", false)
    fun setWakeWord(enabled: Boolean) = prefs.edit().putBoolean("wake_word", enabled).apply()
}
