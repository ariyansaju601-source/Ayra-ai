package com.ayra.assistant.utils

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.ayra.assistant.R
import com.ayra.assistant.models.ChatMessage
import java.text.SimpleDateFormat
import java.util.*

class AyraAdapter(private val messages: List<ChatMessage>) :
    RecyclerView.Adapter<AyraAdapter.MessageViewHolder>() {

    companion object {
        const val VIEW_USER = 0
        const val VIEW_AYRA = 1
    }

    override fun getItemViewType(position: Int) =
        if (messages[position].isUser) VIEW_USER else VIEW_AYRA

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessageViewHolder {
        val layout = if (viewType == VIEW_USER)
            R.layout.item_message_user
        else
            R.layout.item_message_ayra
        val v = LayoutInflater.from(parent.context).inflate(layout, parent, false)
        return MessageViewHolder(v)
    }

    override fun onBindViewHolder(holder: MessageViewHolder, position: Int) {
        holder.bind(messages[position])
    }

    override fun getItemCount() = messages.size

    class MessageViewHolder(v: View) : RecyclerView.ViewHolder(v) {
        private val textView: TextView = v.findViewById(R.id.message_text)
        private val timeView: TextView? = v.findViewById(R.id.message_time)

        fun bind(msg: ChatMessage) {
            textView.text = msg.text
            val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
            timeView?.text = sdf.format(Date(msg.timestamp))
        }
    }
}
