package com.ayra.assistant.services

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import java.io.DataOutputStream

/**
 * AYRA App Launch & Phone Control Service
 * Handles voice commands to open apps, call, SMS, flashlight, etc.
 * Uses both Root (shell) and Accessibility/Intent fallback.
 */
class AppLaunchService(private val context: Context) {

    private val pm: PackageManager = context.packageManager

    // Map of common voice keywords → package names
    private val appMap = mapOf(
        // Social
        "whatsapp" to "com.whatsapp",
        "হোয়াটসঅ্যাপ" to "com.whatsapp",
        "facebook" to "com.facebook.katana",
        "ফেসবুক" to "com.facebook.katana",
        "instagram" to "com.instagram.android",
        "ইনস্টাগ্রাম" to "com.instagram.android",
        "youtube" to "com.google.android.youtube",
        "ইউটিউব" to "com.google.android.youtube",
        "twitter" to "com.twitter.android",
        "x" to "com.twitter.android",
        "telegram" to "org.telegram.messenger",
        "টেলিগ্রাম" to "org.telegram.messenger",
        "tiktok" to "com.zhiliaoapp.musically",
        "snapchat" to "com.snapchat.android",
        // Productivity
        "gmail" to "com.google.android.gm",
        "maps" to "com.google.android.apps.maps",
        "গুগল ম্যাপ" to "com.google.android.apps.maps",
        "chrome" to "com.android.chrome",
        "camera" to "com.android.camera2",
        "ক্যামেরা" to "com.android.camera2",
        "calculator" to "com.android.calculator2",
        "ক্যালকুলেটর" to "com.android.calculator2",
        "clock" to "com.android.deskclock",
        "settings" to "com.android.settings",
        "সেটিংস" to "com.android.settings",
        "play store" to "com.android.vending",
        "spotify" to "com.spotify.music",
        "netflix" to "com.netflix.mediaclient",
        "phone" to "com.android.dialer",
        "contacts" to "com.android.contacts",
        "photos" to "com.google.android.apps.photos",
        "files" to "com.google.android.apps.nbu.files",
        "gallery" to "com.sec.android.gallery3d",
    )

    /**
     * Returns true if the command was handled (no need to send to AI)
     */
    fun handleCommand(input: String): Boolean {
        val lower = input.lowercase().trim()

        // ── OPEN APP ──────────────────────────────────────────────
        val openPhrases = listOf("open ", "খোলো ", "খোল ", "চালু করো ", "start ", "launch ")
        for (phrase in openPhrases) {
            if (lower.startsWith(phrase)) {
                val appName = lower.removePrefix(phrase).trim()
                return openApp(appName)
            }
        }

        // ── CALL ──────────────────────────────────────────────────
        if (lower.startsWith("call ") || lower.startsWith("ফোন করো ") || lower.startsWith("কল করো ")) {
            val name = lower.replace(Regex("(call |ফোন করো |কল করো )"), "").trim()
            makeCall(name)
            return true
        }

        // ── FLASHLIGHT ────────────────────────────────────────────
        if (lower.contains("flashlight on") || lower.contains("torch on") || lower.contains("টর্চ চালু")) {
            toggleFlashlight(true)
            return true
        }
        if (lower.contains("flashlight off") || lower.contains("torch off") || lower.contains("টর্চ বন্ধ")) {
            toggleFlashlight(false)
            return true
        }

        // ── VOLUME ────────────────────────────────────────────────
        if (lower.contains("volume up") || lower.contains("ভলিউম বাড়াও")) {
            runRootCommand("input keyevent 24")
            toast("ভলিউম বাড়ানো হয়েছে")
            return true
        }
        if (lower.contains("volume down") || lower.contains("ভলিউম কমাও")) {
            runRootCommand("input keyevent 25")
            toast("ভলিউম কমানো হয়েছে")
            return true
        }

        // ── SCREENSHOT ────────────────────────────────────────────
        if (lower.contains("screenshot") || lower.contains("স্ক্রিনশট")) {
            runRootCommand("input keyevent 120")
            toast("স্ক্রিনশট নেওয়া হয়েছে!")
            return true
        }

        // ── HOME / BACK ───────────────────────────────────────────
        if (lower == "home" || lower == "হোম") {
            runRootCommand("input keyevent 3")
            return true
        }
        if (lower == "back" || lower == "পিছনে যাও") {
            runRootCommand("input keyevent 4")
            return true
        }

        return false
    }

    private fun openApp(appName: String): Boolean {
        // Check keyword map first
        val pkg = appMap.entries.find { appName.contains(it.key, ignoreCase = true) }?.value

        if (pkg != null) {
            return launchPackage(pkg, appName)
        }

        // Try fuzzy match against installed apps
        val installedApps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        val matched = installedApps.find { app ->
            pm.getApplicationLabel(app).toString().lowercase().contains(appName.lowercase())
        }

        if (matched != null) {
            return launchPackage(matched.packageName, appName)
        }

        toast("\"$appName\" নামের অ্যাপ পাওয়া যায়নি")
        return false
    }

    private fun launchPackage(packageName: String, displayName: String): Boolean {
        return try {
            val intent = pm.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                toast("$displayName খোলা হচ্ছে...")
                true
            } else {
                // Fallback: try root
                runRootCommand("monkey -p $packageName 1")
                toast("$displayName খোলা হচ্ছে (root)...")
                true
            }
        } catch (e: Exception) {
            toast("অ্যাপ খুলতে পারিনি: ${e.message}")
            false
        }
    }

    private fun makeCall(name: String) {
        try {
            val intent = Intent(Intent.ACTION_CALL).apply {
                data = Uri.parse("tel:$name")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            toast("$name-কে কল করা হচ্ছে...")
        } catch (e: Exception) {
            toast("কল করতে পারিনি")
        }
    }

    private fun toggleFlashlight(on: Boolean) {
        try {
            // Using CameraManager for flashlight
            val camManager = context.getSystemService(Context.CAMERA_SERVICE) as android.hardware.camera2.CameraManager
            val cameraId = camManager.cameraIdList[0]
            camManager.setTorchMode(cameraId, on)
            toast(if (on) "টর্চ চালু!" else "টর্চ বন্ধ!")
        } catch (e: Exception) {
            toast("টর্চ নিয়ন্ত্রণ করতে পারিনি")
        }
    }

    /**
     * Execute shell command via root (su)
     */
    private fun runRootCommand(command: String): Boolean {
        return try {
            val process = Runtime.getRuntime().exec("su")
            val os = DataOutputStream(process.outputStream)
            os.writeBytes("$command\n")
            os.writeBytes("exit\n")
            os.flush()
            process.waitFor()
            true
        } catch (e: Exception) {
            // Root not available - silently fail
            false
        }
    }

    private fun toast(msg: String) {
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
        }
    }
}
